#include "hw3.h" //local include to include user defined header
#include<stdio.h>
// Defining all the functions declared in hw3.h file
struct geoData createGeoData(int max, float error, float x)
{
        struct geoData gd;
        gd.maxTerms=max;
        gd.errorTol=error;
        gd.x=x;
        return gd;
}
struct geoData calculateGeo(struct geoData gd)
{
        int i,j;
        float error1=0,sum=0;
        float x,ev=0,product=1;
        x=gd.x;
        ev=1/(1+x);
	//multiplying the value of x with -1,so value for odd powers
	//become negative and even powers become positive automatically
        x=x*(-1);
        for(i=0;i<gd.maxTerms;i++)
	{
                        product=1;
                        for(j=i;j>0;j--)
			{
                                product=product*x;
                        }
                sum=sum+product;
                error1=sum-ev;
                if (error1 < 0)
                {
                        error1=error1*(-1);

                }
                if (error1<gd.errorTol)
		{
                        gd.maxTerms=i+1;
                        gd.x=sum;
                        gd.errorTol=error1;
                        break;
                }
        }
        return gd;
}
void printGeoData(struct geoData gd)
{
        printf("%d %f %f\n",gd.maxTerms,gd.x,gd.errorTol);
}
void calculateGeoSeries(struct geoData gd[],int arraySize)
{
        int i;
        for(i=0;i<arraySize;i++)
	{
                struct geoData a=calculateGeo(gd[i]);
                printGeoData(a);
        }
}
