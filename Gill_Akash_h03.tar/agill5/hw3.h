//Header file
#ifndef HW3_H_
#define HW3_H_//Defining header
//Defining a struct
struct geoData{
	int maxTerms;
	float errorTol;
	float x;
};
//Function to input values
struct geoData createGeoData(int max,float error,float x);
//Function to calculate the geometric serie
struct geoData calculateGeo(struct geoData gd);
//Function to print the output
void printGeoData(struct geoData gd);
//Function to calculate multiple geometric series through array
void calculateGeoSeries(struct geoData gd[],int arraySize);

#endif// end the ifndef

