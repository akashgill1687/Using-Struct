//Homework-3
//Program to calculate the Geometric series till given error tolerance or maximum terms

#include "hw3.h"//Local include to include the user defined header

int main()
{
        struct geoData gd[2];
        gd[0] = createGeoData(50,0.001,0.5);
        gd[1] = createGeoData(50,0.001,0.8);
        calculateGeoSeries(gd,2);
        return 0;
}
